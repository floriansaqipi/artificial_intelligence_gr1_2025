#!/usr/bin/env python3

from sys import argv
from sudoku_board import SudokuBoard
from solution import bfs_with_pruning

def main(board: SudokuBoard) -> SudokuBoard:
    print("duke zgjidhur sudoku me bfs...\n") 
    board = bfs_with_pruning(board) 
    return board

if __name__ == "__main__":
    easy_grid = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],
        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],
        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9],
    ]

    medium_grid = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],
        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],
        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9],
    ]

    hard_grid = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],
        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],
        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9],
    ]
    
    difficulty = argv[1] if len(argv) > 1 else "easy"

    if difficulty == 'hard':
        grid_to_solve = hard_grid
        print("Jemi tu solve per hard grid")
    elif difficulty == 'medium':
        grid_to_solve = medium_grid
        print("Jemi tu solve per medium grid")
    else: 
        grid_to_solve = easy_grid
        print("Jemi tu solve per easy grid")

    board = SudokuBoard(grid_to_solve)
    print(f"Boardi fillestar eshte:\n{board}\n")
    
    solved = main(board)

    print(f"\nBoardi pas zgjidhjes eshte:\n{solved}\n")
